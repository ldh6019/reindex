#!/bin/bash
 
if [ $# -lt 1 ]; then
 echo "parameter empty!"
 exit
fi


if [ -z $1 ]; then
       echo origin index parameter null!!
else
       if [ -z $2 ]; then
               echo new index parameter null!!
       else

	response=$( curl -XPOST  --silent 'localhost:9200/_reindex?pretty' -H 'Content-Type: application/json' -d'
               {
 		 "conflicts": "proceed",
                 "source": {
                   "index": "'$1'"
                 },
                 "dest": {
	           "op_type": "create",
                   "index": "'$2'"
                 }
               }
               ')
       fi
fi

result_msg=$(echo ${response} | jq -r '.|keys[0]' )

 if [ "$result_msg" = error ];then
   echo param index $1
   echo param index $2
   echo  ${response} |  jq .
 else
   echo OK
 fi

