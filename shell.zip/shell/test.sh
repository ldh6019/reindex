#!/bin/bash


curl -XPUT --silent 'localhost:9200/'$1'?pretty' -H 'Content-Type: application/json' -d'
{
    "settings": {
        "index": {
            "analysis": {
                "analyzer": {
                    "arirang_custom": {
                        "type": "custom",
                        "tokenizer": "arirang_tokenizer",
                        "filter": [
                            "lowercase",
                            "trim",
                            "arirang_filter",
                            "ws_synonym"
                        ]
                    }
                },
                "filter": {
                    "ws_synonym": {
                        "type": "synonym",
                        "synonyms_path": "dictionary/org/apache/lucene/analysis/ko/dic/synonyms.dic"
                    }
                }
            }
        }
    },
    "mappings": {
        "product": {
            "properties": {
                "registerd_time": {
                    "format": "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis",
                    "type": "date"
                },
                "click": {
                    "type": "float"
                },
                "click_update_time": {
                    "format": "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis",
                    "type": "date"
                },
                "title": {
                    "analyzer": "arirang_custom",
                    "type": "text"
                },
                "click_registerd_time": {
                    "format": "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis",
                    "type": "date"
                }
            }
        }
    }
}
'

