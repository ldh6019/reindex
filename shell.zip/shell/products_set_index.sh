#!/bin/bash

if [ $# -lt 1 ];then
        echo 'parameter empty  count : ' $#
#echo 'NO'
else
#        echo $1' index put process'
response=$(curl -XPUT --silent 'localhost:9200/'$1'/_settings?pretty' -H 'Content-Type: application/json' -d'
{
    "index" : {
	"number_of_replicas" : 0,
        "refresh_interval" : "-1"
    }
}
'
)

result_msg=$( echo ${response} |  jq '.acknowledged' )

 if [ "$result_msg" = true ];then
        echo OK
  else
	echo param index $1
        echo  ${response} |  jq .
  fi
fi

