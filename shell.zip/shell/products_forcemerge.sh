#!/bin/bash

if [ $# -lt 1 ];then
        echo 'parameter empty  count : ' $#
#echo 'NO'
else
#        echo $1' index put process'
response=$(curl -XPUT --silent 'localhost:9200/'$1'/_settings?pretty' -H 'Content-Type: application/json' -d'
{
    "index" : {
	"number_of_replicas" : 1,
        "refresh_interval" : null
    }
}
'
)


result_msg=$( echo ${response} |  jq '.acknowledged' )

 if [ "$result_msg" = true ];then
	merge_response=$(curl -XPOST --silent 'localhost:9200/'$1'/_forcemerge?pretty')


success_count=${merge_response} |  jq '._shards.successful'




	if [ "$success_count" = 0 ];then 

         	echo forcemerge interval error
                echo param index $1
                echo  ${response} |  jq .
                exit


	else 
		echo OK

	fi



  else
	echo refresh interval error
        echo param index $1
        echo  ${response} |  jq .
	exit
  fi





fi

