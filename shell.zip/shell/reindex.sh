#!/bin/bash
echo "reindex script start" 
echo "---------------------------------------------------"

function echo_timestamp() {
    echo "["`date "+%Y-%m-%d %H:%M:%S %z %Z"`"]" $*
}

index_name=products_$(date +"%Y-%m-%d")
LOG=logs/reindex_$(date +"%Y-%m-%d").log

echo $index_name" index created!!"
echo "-----------------------------------------------------------------"
echo "================= Step 1.Same index delete script ==================="
echo "================= Step 1.Same index delete script ===================" >> ${LOG}
echo "Delete index : ["`date "+%Y-%m-%d %H:%M:%S %z %Z"`"]" $* >> ${LOG}
delete_respnose=$(./delete_index.sh $index_name)
echo  "delete status : "$delete_respnose >> ${LOG}

if [ "$delete_respnose" != 'OK' ];then
 echo 'DELETE ERROR'
 exit 0;
fi
echo "delete complated!!" >> ${LOG}

echo "================= Step 2.Put index script ==========================="
echo "================= Step 2.Put index script ===========================" >> ${LOG}
echo "Put index : ["`date "+%Y-%m-%d %H:%M:%S %z %Z"`"]" $* >> ${LOG}
put_response=$(./products_put_index.sh $index_name)
echo  "put status : "$put_respnose >> ${LOG}

if [ "$put_response" != 'OK' ];then
 echo 'PUT ERROR'
 exit 0;
fi
echo "put index complated!!" >> ${LOG}

echo "================= Step 3.Set index script ==========================="
echo "================= Step 3.Set index script ===========================" >> ${LOG}
echo "Set index : ["`date "+%Y-%m-%d %H:%M:%S %z %Z"`"]" $* >> ${LOG}
set_response=$(./products_set_index.sh $index_name )
echo  "set status : "$set_response >> ${LOG}

if [ "$put_response" != 'OK' ];then
 echo 'SET ERROR'
 exit 0;
fi
echo "set index complated!!" >> ${LOG}

echo "================= Step 4.Get alias & reindex script ================="
echo "================= Step 4.Get alias & reindex script =================" >> ${LOG}
echo "reindex : ["`date "+%Y-%m-%d %H:%M:%S %z %Z"`"]" $* >> ${LOG}

alias=ws_products
origin_index=$(./alias_index.sh $alias)
reindex_response=$(./products_reindex.sh $origin_index $index_name)
echo  "reindex status : "$reindex_response >> ${LOG}

if [ "$reindex_response" != 'OK' ];then
 echo 'REINDEX ERROR'
 exit
fi
echo "reindex complated!!" >> ${LOG}

echo "================= Step 5.Reindex add optype script =================="
echo "================= Step 5.Reindex add optype script ==================" >> ${LOG}
echo "reindex optype : ["`date "+%Y-%m-%d %H:%M:%S %z %Z"`"]" $* >> ${LOG}

optype_response=$(./products_reindex_optype.sh $origin_index $index_name)
echo  "optype status : "$optype_response >> ${LOG}

if [ "$reindex_response" != 'OK' ];then
 echo 'REINDEX OPTYPE ERROR'
 exit
fi
echo "reindex optype complated!!" >> ${LOG}

echo "================= Step 6.Forcemerge script =========================="
echo "================= Step 6.Forcemerge script ==========================" >> ${LOG}
echo "forcemerge : ["`date "+%Y-%m-%d %H:%M:%S %z %Z"`"]" $* >> ${LOG}

merge_response=$(./products_forcemerge.sh $index_name )
echo  "merge status : "$merge_response >> ${LOG}

if [ "$merge_response" != 'OK' ];then
 echo 'MERGE ERROR'
 exit
fi
echo "forcemerge complated!!" >> ${LOG}

echo "================= Step 7.Alias change script ========================"
echo "================= Step 7.Alias change script ========================" >> ${LOG}
echo "Alias change : ["`date "+%Y-%m-%d %H:%M:%S %z %Z"`"]" $* >> ${LOG}

alias_change_response=$(./alias_change.sh $origin_index $index_name $alias )
echo  "alias change status : "$alias_change_response >> ${LOG}
echo $alias_change_response





