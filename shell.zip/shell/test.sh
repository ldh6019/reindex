#!/bin/bash



curl -XGET 'localhost:9200/_alias/dooo'






