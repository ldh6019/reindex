#!/bin/bash

if [ $# -lt 1 ];then
	echo 'parameter empty  count : ' $#
else 

#	echo $1' index delete process'
response=$(curl -XGET --silent 'localhost:9200/_alias/'$1)
#echo $response
#echo 'OK'
#echo  ${response} |  jq .
#echo '====================================='
index=$(echo ${response} | jq -r '.|keys[0]' )
echo $index
exit
#echo '====================================='
fi


