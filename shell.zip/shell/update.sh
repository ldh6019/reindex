#!/bin/bash

StartTime=$(date +%s)
#WMPLBBUP0X3aW8
curl -XPOST 'localhost:9200/doo/_update_by_query?conflicts=proceed&pretty' -H 'Content-Type: application/json' -d'
{
    "script": {
        "inline": "ctx._source.click++",
        "lang": "painless"
    },
    "query": {
        "bool": {
            "must": [
                {
                    "term": {
                        "wmp_vendor_id.keyword": "'$1'"
                    }
                }
            ]
        }
    }
}
'

EndTime=$(date +%s)
echo "update 실생시간 :  $(($EndTime - $StartTime)) seconds to complete."





