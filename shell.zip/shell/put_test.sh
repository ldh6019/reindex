#!/bin/bash

if [ $# -lt 1 ];then
        echo 'parameter empty  count : ' $#
#echo 'NO'
else
#        echo $1' index put process'
response=$(curl -XPUT --silent 'localhost:9200/'$1'?pretty' -H 'Content-Type: application/json' -d'
{
    "settings": {
        "index": {
            "analysis": {
                "analyzer": {
                    "arirang_custom": {
                        "type": "custom",
                        "tokenizer": "arirang_tokenizer",
                        "filter": [
                            "lowercase",
                            "trim",
                            "arirang_filter",
                            "ws_synonym"
                        ]
                    }
                },
                "filter": {
                    "ws_synonym": {
                        "type": "synonym",
                        "synonyms_path": "dictionary/org/apache/lucene/analysis/ko/dic/synonyms.dic"
                    }
                }
            }
        }
    },
    "mappings": {
        "product": {
            "properties": {
                "registerd_time": {
                    "format": "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis",
                    "type": "date"
                },
                "click": {
                    "type": "float"
                },
                "click_update_time": {
                    "format": "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis",
                    "type": "date"
                },
                "click_registerd_time": {
                    "format": "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis",
                    "type": "date"
                }
            }
        }
    }
}
')

result_msg=$( echo ${response} |  jq '.acknowledged' )

 if [ "$result_msg" = true ];then
        echo OK
  else
	echo param index $1
        echo  ${response} |  jq .
  fi
fi

