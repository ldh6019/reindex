#!/bin/bash

size=$#

if [ $size -ne 3 ]; then
        echo "Usage : shard.sh indice_name shard_number node_name";
        echo "Example : shard.sh ws_products 3 node_name";
        exit 0;
fi

indice=$1
shard=$2
node=$3

curl -XPOST 'localhost:9200/_cluster/reroute?retry_failed=true&pretty' -H 'Content-Type: application/json' -d'
{
    "commands" : [
        {
          "allocate_replica" : {
                "index" : "'$indice'", "shard" : '$shard',
                "node" : "'$node'"
          }
        }
    ]
}
'

