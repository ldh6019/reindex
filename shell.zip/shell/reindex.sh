#!/bin/bash

index_name=products_$(date +"%Y-%m-%d")_dev

delete_respnose=$(./delete_index.sh $index_name | tee -a logs/delete-log-$(date +"%Y-%m-%d").log)
if [ "$delete_respnose" != 'OK' ];then
 echo 'DELETE ERROR'
 exit
fi

put_response=$(./products_put_index.sh $index_name | tee -a logs/index-put-log-$(date +"%Y-%m-%d").log )
if [ "$put_response" != 'OK' ];then
 echo 'PUT ERROR'
 exit
fi

set_response=$(./products_set_index.sh $index_name | tee -a logs/index-set-log-$(date +"%Y-%m-%d").log )
if [ "$put_response" != 'OK' ];then
 echo 'SET ERROR'
 exit
fi

alias=ws_products
origin_index=$(./alias_index.sh $alias)
reindex_response=$(./products_reindex.sh $origin_index $index_name | tee -a logs/reindex-log-$(date +"%Y-%m-%d").log)

if [ "$reindex_response" != 'OK' ];then
 echo 'REINDEX ERROR'
 exit
fi

optype_response=$(./products_reindex_optype.sh $origin_index $index_name | tee -a logs/reindex_optype-log-$(date +"%Y-%m-%d").log)

if [ "$reindex_response" != 'OK' ];then
 echo 'REINDEX OPTYPE ERROR'
 exit
fi

merge_response=$(./products_forcemerge.sh $index_name | tee -a logs/index-merge-log-$(date +"%Y-%m-%d").log )
if [ "$merge_response" != 'OK' ];then
 echo 'MERGE ERROR'
 exit
fi

alias_change_response=$(./alias_change.sh $origin_index $index_name $alias | tee -a logs/alias-change-log-$(date +"%Y-%m-%d").log )
echo $alias_change_response





