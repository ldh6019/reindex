#!/bin/bash

if [ $# -lt 1 ];then
	echo 'parameter empty  count : ' $#
else 
#	echo $1' index delete process'
response=$(curl -XDELETE --silent 'localhost:9200/'$1)
#echo $response
#echo 'OK'
#echo  ${response} |  jq .
#echo '====================================='
status_code=$( echo ${response} |  jq '.status' )
result_msg=$( echo ${response} |  jq '.acknowledged' )
  if [ "$status_code" = 404 -o "$result_msg" = true ];then
	echo OK
  else
	echo param index S1 
        echo  ${response} |  jq .
  fi
fi


