#!/bin/bash

if [ $# -lt 3 ];then
	echo 'parameter not enough count : ' $#
else 

#	echo $1' index delete process'
response=$(curl -XPOST --silent 'localhost:9200/_aliases?pretty' -H 'Content-Type: application/json' -d'
{
    "actions" : [
        { "remove" : { "index" : "'$1'", "alias" : "'$3'" } },
        { "add" : { "index" : "'$2'", "alias" : "'$3'" } }
    ]
}
')


result_msg=$( echo ${response} |  jq '.acknowledged' )

 if [ "$result_msg" = true ];then
        echo OK
  else
	echo index1 : $1
        echo index2 : $2
        echo alias : $3
        echo ${response} |  jq .
  fi

#echo '====================================='
fi


