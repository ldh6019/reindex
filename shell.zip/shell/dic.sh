#!/bin/bash

dic_domain='http://dics.wonder-pay.com'
es_dic_path='/elastic/elasticsearch-5.5.0/config/dictionary/org/apache/lucene/analysis/ko/dic'

wget -q $dic_domain/eomi.dic -O $es_dic_path/eomi.dic
wget -q $dic_domain/extension.dic -O $es_dic_path/extension.dic
wget -q $dic_domain/josa.dic -O $es_dic_path/josa.dic
wget -q $dic_domain/prefix.dic -O $es_dic_path/prefix.dic
wget -q $dic_domain/suffix.dic -O $es_dic_path/suffix.dic
wget -q $dic_domain/syllable.dic -O $es_dic_path/syllable.dic
wget -q $dic_domain/synonyms.dic -O $es_dic_path/synonyms.dic
wget -q $dic_domain/total.dic -O $es_dic_path/total.dic

response=$(curl -XGET --silent http://localhost:9200/_arirang_dictionary_reload)

echo $response


